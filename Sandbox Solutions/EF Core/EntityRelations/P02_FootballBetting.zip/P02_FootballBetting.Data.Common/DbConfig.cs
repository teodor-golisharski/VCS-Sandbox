﻿namespace P02_FootballBetting.Data.Common
{
    public static class DbConfig
    {
        public static string ConnectionString = @"Server=.;Database=FootballBookmakerSystem;Integrated Security=True;";
    }
}
