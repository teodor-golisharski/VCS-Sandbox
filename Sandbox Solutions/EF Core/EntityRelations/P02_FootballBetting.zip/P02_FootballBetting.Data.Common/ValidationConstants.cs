﻿namespace P02_FootballBetting.Data.Common
{
    public class ValidationConstants
    {
        public const int InitialsLength = 3;
        public const int ResultMaxLength = 10;
    }
}
