﻿namespace P01_StudentSystem.Data
{
    public static class DbConfig
    {
        public static string ConnectionString = @"Server=.;Database=StudentSystem;Integrated Security=True;";
    }
}